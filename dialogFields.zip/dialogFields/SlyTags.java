package com.mindtree.sightlySling.core.models;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class SlyTags {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	
	@Default(values = "pavan")
	@Inject
	private String name;

	@Inject
	private boolean gender;

	@Inject
	private String path;

	@Inject
	private List<String> books;

	@Inject
	private String selectit;

	@Inject
	private String age;

	@Inject
	private String textArea;

	
	/* to return values to component */
	public String getName() {
		return name;
	}

	public boolean isGender() {
		return gender;
	}

	public String getPath() {
		return path;
	}

	public List<String> getBooks() {
		if (books != null) {
			return new ArrayList<String>(books);
		} else {
			return Collections.emptyList();
		}
	}

	public String getSelectit() {
		return selectit;
	}

	public String getAge() {
		return age;
	}

	public String getTextArea() {
		return textArea;
	}

	public Logger getLogger() {
		return logger;
	}

	
	/* to print values in loggers */
	@PostConstruct
	protected void init() {
		logger.info("name1 : " + name);
		logger.info("gender2 : " + gender);
		logger.info("path3 : " + path);
		logger.info("option4 : " + selectit);
		logger.info("list5 : " + books);
		logger.info("textArea6 : " + textArea);
		logger.info("age7 : " + age);
	}

}
